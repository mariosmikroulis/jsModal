<html>
<body>
<b>Dear Staff,</b><br>

<p>
    This is the Automatic System of Liberty Cars to notify you about the following:<br>
    {{details}}
</p>

<p>Please, login to <a href="https://cabadmin.minicabsinlondon.com">Cabadmin</a> and have a look into the above. Also, do not reply to this email. If you would like to contact us, please email us at <a href="mailto:driver@minicabsinlondon.com">driver@minicabsinlondon.com</a>.</p><br>

Kind regards,<br><br>
Drivers In London (Automated System)
Liberty Cars - 0208 900 5555,<br>
216/218 Preston Road,<br>
London,<br>
HA9 8PB<br>
</body>
</html>