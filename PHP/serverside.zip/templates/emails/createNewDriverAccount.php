<!DOCTYPE><html><body>
<b>Dear {{driverName}},</b><br>
<p>We are writing you to inform you that your application you have made to <a href="https://www.driversinlondon.com/">DriversinLondon.com</a> was successful.<br>
    <br>
    The next step is to answer our phone call, where we will set everything up with you. Please make sure you will our phone call up. After that call, you will be able to finally start working with us immediately.
</p>
<br>
Kind regards,<br>
Liberty Cars - 0208 900 5555,<br>
216/218 Preston Road,<br>
London,<br>
HA9 8PB<br>
</body></html>