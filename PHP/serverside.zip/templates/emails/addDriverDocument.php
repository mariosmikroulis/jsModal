<html>
<body>
<b>Dear {{driverName}},</b><br>

<p>We are writing you to confirm that we have received the document you have uploaded on <a href="https://driverprtal.driversinlondon.com">Driver Portal</a>, and it will be reviewed by a member of our staff. Please allow us 48 hours to review your document.<br> You can see if we have accepted or declined your document on <a href="https://driverprtal.driversinlondon.com">Driver Portal</a>. You might also receive a notification email.<br><br>
    If you have any questions, please do not hesitate to contact us at <a href="tel:02089005555"><b>0208 900 5555</b></a> alternatively email us at <a href="mailto:driver@minicabsinlondon.com"><b>driver@minicabsinlondon.com</b></a></p>

Kind regards,<br><br>
Liberty Cars - 0208 900 5555,<br>
216/218 Preston Road,<br>
London,<br>
HA9 8PB<br>
</body>
</html>