<html>
<body>
<b>Dear {{name}},</b><br>

<p>
    This is an automated message by the server informing you that the look-up <a href="https://www.locate.com/">Loqate</a> service has the following issue:<br>
    Description - {{description}}<br>
    Cause: - {{cause}}<br>
    Resolution: - {{resolution}}<br><br>
    Please address those issues with a fix as soon as possible!
</p>

Kind regards,<br><br>
Liberty Cars - 0208 900 5555,<br>
216/218 Preston Road,<br>
London,<br>
HA9 8PB<br>
</body>
</html>