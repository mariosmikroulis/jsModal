<html>
<body>
<b>Dear {{driverName}},</b><br>

<p>
    We are writing you to inform you that a member of our staff has recently replied to one of your opened tickets with the subject:<br>
    {{subject}}<br><br>
    Please login on <a href="https://driverportal.driversinlondon.com/">Driver Portal</a>, go to the Tickets page from the navigation and open your ticket to view it.<br>
</p>


Kind regards,<br><br>
Liberty Cars - 0208 900 5555,<br>
216/218 Preston Road,<br>
London,<br>
HA9 8PB<br>
</body>
</html>