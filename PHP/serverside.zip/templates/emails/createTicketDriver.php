<html>
<body>
<b>Dear {{driverName}},</b><br>

<p>We are writing you to confirm that we have received your ticket for the following subject:<br>
    {{subject}}<br><br>

    Please, allow us 48 hours to get back to you. You still have to login on the driver portal and check yourself if we come back to you.<br>
    <br>
    If you have any question, or have any issue, please do not hesitate to contact us at <a href="tel:02089005555"><b>0208 900 5555</b></a>, alternatively, email us at <a href="mailto:driver@minicabsinlondon.com"><b>driver@minicabsinlondon.com</b></a>!</p>

PS: Do not reply to this email as is been used for our automated system. If you want to discuss, contact us via the information above<br><br>


Kind regards,<br><br>
Liberty Cars - 0208 900 5555,<br>
216/218 Preston Road,<br>
London,<br>
HA9 8PB<br>
</body>
</html>