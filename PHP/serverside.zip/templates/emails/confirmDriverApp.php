<html>
    <body>
        <b>Dear {{driverName}},</b><br>

        <p>We are writing you to confirm that we have received your application, and it will be reviewed by a member of our staff and you will be contacted in the next 48 hours on {{mobileNumber}}.<br><br>
            If you have any questions, please do not hesitate to contact us at <a href="tel:02089005555"><b>0208 900 5555</b></a> alternatively email us at <a href="mailto:driver@minicabsinlondon.com"><b>driver@minicabsinlondon.com</b></a></p>

        <br>We are looking forward to contacting with you.<br>

        Kind regards,<br><br>
        Liberty Cars - 0208 900 5555,<br>
        216/218 Preston Road,<br>
        London,<br>
        HA9 8PB<br>
    </body>
</html>