<html>
<body>
<b>Dear {{driverName}},</b><br>

<p>We are writing you to confirm that we have received your payment of &pound;{{amount}}, and therefore, your driver account has been topped up.<br>
    Your receipt reference number is:<br>
    #<b>{{receipt}}</b>
    <br><br>
    If you have any question, or have any issue, please do not hesitate to contact us at <a href="tel:02089005555"><b>0208 900 5555</b></a>, alternatively, email us at <a href="mailto:driver@minicabsinlondon.com"><b>driver@minicabsinlondon.com</b></a>!</p>

PS: Do not reply to this email as is been used for our automated system. If you want to discuss, contact us via the information above<br><br>


Kind regards,<br><br>
Liberty Cars - 0208 900 5555,<br>
216/218 Preston Road,<br>
London,<br>
HA9 8PB<br>
</body>
</html>