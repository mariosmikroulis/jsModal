<html>
<body>
<b>Dear {{name}},</b><br>

<p>
    This is an automated message by the server informing you that your <a href="https://www.locate.com/">Loqate</a> account has run out of credit. Please Top-up the account as soon as possible.
</p>

Kind regards,<br><br>
Liberty Cars - 0208 900 5555,<br>
216/218 Preston Road,<br>
London,<br>
HA9 8PB<br>
</body>
</html>