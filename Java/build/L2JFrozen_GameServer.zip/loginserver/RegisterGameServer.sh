#!/bin/sh
java -Djava.util.logging.config.file=console.cfg -cp lib/*:lib/l2jfrozen-core.jar com.l2jfrozen.gsregistering.GameServerRegister
