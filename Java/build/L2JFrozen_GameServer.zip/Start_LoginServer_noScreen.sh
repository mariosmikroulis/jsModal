#!/bin/bash
cd loginserver
nohup ./LoginServer_loop.sh &
cd ..
