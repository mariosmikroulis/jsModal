#!/bin/bash

java -Dfile.encoding=UTF- -cp lib/*:l2jfrozen-core.jar com.l2jfrozen.gameserver.powerpak.xmlrpc.XMLRPCClient_ManagementTester

