#!/bin/bash
cd gameserver
nohup ./GameServer_loop.sh &
cd ..
